<?php 
include_once("header-eng.php");

?>





<!-- header area end -->
<!-- hero area start -->

<!-- main menu area end -->
<!-- breadcroumb area start -->
<div class="tractour-breadcroumb breadcroumb-bg text-center">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h2> Pride </h2>
                <h4><a href="index.php">Homepage </a>Pride</h4>
            </div>
        </div>
    </div>
</div>
<!-- breadcroumb area end -->
</div>
<!-- hero area end -->
<!-- shop area start -->
<div class="shop-area sec-p-100">
    <div class="container">
        <div class="row">


        </div>
        <div class="spacer-20"></div>
        <div class="row"><div class="col-md-3">
                <div class="single-product-wrap text-center">
                    <div class="">
                        <a href="#">
                            <img src="assets/img/shop/parts/Pride/(151) Pride Pickup Drum Brakes.jpg" alt="product" class="img-fluid" /></a>


                        <div class="sale-tag">

                        </div>
                    </div>
                    <div class="product-content">
                        <h4><a href="#" class="product-title">(151) Pride Pickup Drum Brakes</a></h4>
                        <div class="product-price">

                        </div>

                    </div>
                </div>
            </div>


<div class="col-md-3">
                <div class="single-product-wrap text-center">
                    <div class="">
                        <a href="#">
                            <img src="assets/img/shop/parts/Pride/151 Pride Pickup Brake Assy.jpg" alt="product" class="img-fluid" /></a>


                        <div class="sale-tag">

                        </div>
                    </div>
                    <div class="product-content">
                        <h4><a href="#" class="product-title">151 Pride Pickup Brake Assy</a></h4>
                        <div class="product-price">

                        </div>

                    </div>
                </div>
            </div>


<div class="col-md-3">
                <div class="single-product-wrap text-center">
                    <div class="">
                        <a href="#">
                            <img src="assets/img/shop/parts/Pride/151 Pride Pickup Drum Brakes.jpg" alt="product" class="img-fluid" /></a>


                        <div class="sale-tag">

                        </div>
                    </div>
                    <div class="product-content">
                        <h4><a href="#" class="product-title">151 Pride Pickup Drum Brakes</a></h4>
                        <div class="product-price">

                        </div>

                    </div>
                </div>
            </div>


<div class="col-md-3">
                <div class="single-product-wrap text-center">
                    <div class="">
                        <a href="#">
                            <img src="assets/img/shop/parts/Pride/ABS Pride Plate Assy.R.Back.jpg" alt="product" class="img-fluid" /></a>


                        <div class="sale-tag">

                        </div>
                    </div>
                    <div class="product-content">
                        <h4><a href="#" class="product-title">ABS Pride Plate Assy</a></h4>
                        <div class="product-price">

                        </div>

                    </div>
                </div>
            </div>


<div class="col-md-3">
                <div class="single-product-wrap text-center">
                    <div class="">
                        <a href="#">
                            <img src="assets/img/shop/parts/Pride/Pride Back Plates.jpg" alt="product" class="img-fluid" /></a>


                        <div class="sale-tag">

                        </div>
                    </div>
                    <div class="product-content">
                        <h4><a href="#" class="product-title">Pride Back Plates</a></h4>
                        <div class="product-price">

                        </div>

                    </div>
                </div>
            </div>


<div class="col-md-3">
                <div class="single-product-wrap text-center">
                    <div class="">
                        <a href="#">
                            <img src="assets/img/shop/parts/Pride/Pride Brake Assy.jpg" alt="product" class="img-fluid" /></a>


                        <div class="sale-tag">

                        </div>
                    </div>
                    <div class="product-content">
                        <h4><a href="#" class="product-title">Pride Brake Assy</a></h4>
                        <div class="product-price">

                        </div>

                    </div>
                </div>
            </div>


<div class="col-md-3">
                <div class="single-product-wrap text-center">
                    <div class="">
                        <a href="#">
                            <img src="assets/img/shop/parts/Pride/Pride Front Brake pads.jpg" alt="product" class="img-fluid" /></a>


                        <div class="sale-tag">

                        </div>
                    </div>
                    <div class="product-content">
                        <h4><a href="#" class="product-title">Pride Front Brake pads</a></h4>
                        <div class="product-price">

                        </div>

                    </div>
                </div>
            </div>


<div class="col-md-3">
                <div class="single-product-wrap text-center">
                    <div class="">
                        <a href="#">
                            <img src="assets/img/shop/parts/Pride/Pride Front Disk (2).jpg" alt="product" class="img-fluid" /></a>


                        <div class="sale-tag">

                        </div>
                    </div>
                    <div class="product-content">
                        <h4><a href="#" class="product-title">Pride Front Disk (2)</a></h4>
                        <div class="product-price">

                        </div>

                    </div>
                </div>
            </div>


<div class="col-md-3">
                <div class="single-product-wrap text-center">
                    <div class="">
                        <a href="#">
                            <img src="assets/img/shop/parts/Pride/Pride Front Disk.jpg" alt="product" class="img-fluid" /></a>


                        <div class="sale-tag">

                        </div>
                    </div>
                    <div class="product-content">
                        <h4><a href="#" class="product-title">Pride Front Disk</a></h4>
                        <div class="product-price">

                        </div>

                    </div>
                </div>
            </div>


<div class="col-md-3">
                <div class="single-product-wrap text-center">
                    <div class="">
                        <a href="#">
                            <img src="assets/img/shop/parts/Pride/Pride Junior Shoes.jpg" alt="product" class="img-fluid" /></a>


                        <div class="sale-tag">

                        </div>
                    </div>
                    <div class="product-content">
                        <h4><a href="#" class="product-title">Pride Junior Shoes</a></h4>
                        <div class="product-price">

                        </div>

                    </div>
                </div>
            </div>


<div class="col-md-3">
                <div class="single-product-wrap text-center">
                    <div class="">
                        <a href="#">
                            <img src="assets/img/shop/parts/Pride/Pride Pickup Brakes.jpg" alt="product" class="img-fluid" /></a>


                        <div class="sale-tag">

                        </div>
                    </div>
                    <div class="product-content">
                        <h4><a href="#" class="product-title">Pride Pickup Brakes</a></h4>
                        <div class="product-price">

                        </div>

                    </div>
                </div>
            </div>


<div class="col-md-3">
                <div class="single-product-wrap text-center">
                    <div class="">
                        <a href="#">
                            <img src="assets/img/shop/parts/Pride/Pride Pickup Drum Brakes.jpg" alt="product" class="img-fluid" /></a>


                        <div class="sale-tag">

                        </div>
                    </div>
                    <div class="product-content">
                        <h4><a href="#" class="product-title">Pride Pickup Drum Brakes</a></h4>
                        <div class="product-price">

                        </div>

                    </div>
                </div>
            </div>


<div class="col-md-3">
                <div class="single-product-wrap text-center">
                    <div class="">
                        <a href="#">
                            <img src="assets/img/shop/parts/Pride/Pride Rear Axle.jpg" alt="product" class="img-fluid" /></a>


                        <div class="sale-tag">

                        </div>
                    </div>
                    <div class="product-content">
                        <h4><a href="#" class="product-title">Pride Rear Axle</a></h4>
                        <div class="product-price">

                        </div>

                    </div>
                </div>
            </div>


<div class="col-md-3">
                <div class="single-product-wrap text-center">
                    <div class="">
                        <a href="#">
                            <img src="assets/img/shop/parts/Pride/Pride Rear Brake pads.jpg" alt="product" class="img-fluid" /></a>


                        <div class="sale-tag">

                        </div>
                    </div>
                    <div class="product-content">
                        <h4><a href="#" class="product-title">Pride Rear Brake pads</a></h4>
                        <div class="product-price">

                        </div>

                    </div>
                </div>
            </div>


<div class="col-md-3">
                <div class="single-product-wrap text-center">
                    <div class="">
                        <a href="#">
                            <img src="assets/img/shop/parts/Pride/Pride Rear Cylinder.jpg" alt="product" class="img-fluid" /></a>


                        <div class="sale-tag">

                        </div>
                    </div>
                    <div class="product-content">
                        <h4><a href="#" class="product-title">Pride Rear Cylinder</a></h4>
                        <div class="product-price">

                        </div>

                    </div>
                </div>
            </div>


<div class="col-md-3">
                <div class="single-product-wrap text-center">
                    <div class="">
                        <a href="#">
                            <img src="assets/img/shop/parts/Pride/Pride Rear Hub Spindle.jpg" alt="product" class="img-fluid" /></a>


                        <div class="sale-tag">

                        </div>
                    </div>
                    <div class="product-content">
                        <h4><a href="#" class="product-title">Pride Rear Hub Spindle</a></h4>
                        <div class="product-price">

                        </div>

                    </div>
                </div>
            </div>


<div class="col-md-3">
                <div class="single-product-wrap text-center">
                    <div class="">
                        <a href="#">
                            <img src="assets/img/shop/parts/Pride/Tiba & 151 Rear Hub Spindle.jpg" alt="product" class="img-fluid" /></a>


                        <div class="sale-tag">

                        </div>
                    </div>
                    <div class="product-content">
                        <h4><a href="#" class="product-title">Tiba & 151 Rear Hub Spindle</a></h4>
                        <div class="product-price">

                        </div>

                    </div>
                </div>
            </div>


                </div>
            </div>


        </div>
    </div>
</div>
    <!-- quote sologan area end -->
    <!-- footer area start -->


    <?php 
    include_once("footer-eng.php");


    ?> 