<?php 
include_once("header.php");

?>
    <!-- header area end -->
    <!-- hero area start -->
   
        <!-- main menu area end -->
        <!-- slider area start -->
        <div class="slider-area">
            <div class="tractor-main-slider owl-carousel owl-theme">


            
                <!-- Slide 1 -->


                <div class="tractor-single-slider slid-bg-1">
                    <div class="tractor-single-table">
                        <div class="tractor-single-tablecell">
                            <div class="container">
                                <div class="row">
                                    <div class="col-md-12">
                                     
                                    
                                           
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>



                <!-- Slide 2 -->



                <div class="tractor-single-slider slid-bg-2">
                    <div class="tractor-single-table">
                        <div class="tractor-single-tablecell">
                            <div class="container">
                                <div class="row">
                                    <div class="col-md-12">
                                    



                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- slider area end -->

        <!-- blocks services area stat -->
        <div class="blocks-services-area text-center mb-100 minus-t-100 wow fadeInUp">
            <div class="container">
                <div class="row">
                    <div class="col-md-4">
                        <div class="single-blocks-services">
                            <div class="single-blocks-img">
                                <img src="assets/img/blocks/blocks-1.jpg" alt="" class="img-fluid" />
                            </div>
                            

                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="single-blocks-services">
                            <div class="single-blocks-img">
                                <img src="assets/img/blocks/blocks-2.jpg" alt="" class="img-fluid" />
                            </div>
                          

                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="single-blocks-services">
                            <div class="single-blocks-img">
                                <img src="assets/img/blocks/blocks-3.jpg" alt="" class="img-fluid" />
                            </div>
                       

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- blocks services area end -->
    </div>
    <!-- hero area end -->

    <!-- project area start -->
  
    <!-- project area end -->
    <!-- about us area start -->
    <div class="about-area sec-p-100">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h2> شرکت در یک نگاه</h2>
                    <p> شرکت روئین صنعت نوین بالغ بر ۳۰ سال است که در صنعت خودرو کشور مشغول به فعالیت می باشد این شرکت
                        در شهرهای اصفهان و تهران در ۴ شعبه با تولیدات مختلف همیشه سعی داردتا با پیشرفتهای روز جهانی
                        همگام و پیشگام در بروز رسانی در این عرصه بوده .استفاده از تجهیزات روز دنیا در زمینه تولید و
                        اندازه گیری و کنترل از افتخارات این شرکت می باشد.
                        این شرکت که با گروه خودرو سازی سایپا و ایران خودروبه صورت مستقیم و بی واسطه در ارتباط می باشدو
                        در زمینه تولید انواع اکسل خودرو و قطعات بدنه و داشبورد و سیستم ترمز جلوو عقب تولیدات خود را
                        مستقیما به خطوط تولید oem ارسال می نماید. </p>
                   
                </div>
                <div class="col-md-6">
                    <div class="about-slider-wraper owl-carousel owl-theme">
                        <div class="about-single-item">
                            <img src="assets/img/about/about-1.jpg" alt="about-img" class="img-fluid" />
                            <h4>فن آوری های تجربی صنعتی</h4>
                        </div>
                        <div class="about-single-item">
                            <img src="assets/img/about/about-2.jpg" alt="about-img" class="img-fluid" />
                            <h4>فن آوری های تجربی صنعتی</h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- about us area end -->
    <!-- counter area start -->
   
    <!-- counter area end -->
    <!-- services area start -->
    <div class="services-area sec-p-100 text-center">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <div class="single-services-wraper border-bottom">
                        <div class="services-icon">
                            <i class="flaticon-oil"></i>
                        </div>
                        <div class="services-content">
                            <h4> صرفه جویی در هزینه </h4>
                            <p> به کار گیری بهترین مواد اولییه</p>
                        </div>
                    </div>
                </div>

                

                <div class="col-md-4">
                    <div class="single-services-wraper border-bottom">
                        <div class="services-icon">
                            <i class="flaticon-chip"></i>
                        </div>
                        <div class="services-content">
                            <h4>هوش مصنوعی</h4>
                            <p>به کار گیری ربات در خط تولید </p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4">
                    <div class="single-services-wraper">
                        <div class="services-icon">
                            <i class="flaticon-atom"></i>
                        </div>
                        <div class="services-content">
                            <h4> تولید مطابق استاندارد های اوروپا</h4>
                            <p> دارنده ایزو 9002 </p>
                        </div>
                    </div>
                </div>

               

                <div class="col-md-4">
                    <div class="single-services-wraper">
                        <div class="services-icon">
                            <i class="flaticon-idea"></i>
                        </div>
                        <div class="services-content">
                            <h4> به کار گیری نیروی متخصص </h4>
                            <p> نیروهای متخصص ما در مدرن ترین آزمایش گاه بهترین کالا را در اختیار شما قرار میدهند</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 
   <br>
    <!-- video and accordian area end -->
    <!-- blog area start -->
    <div class="blog-area pb-85">
        <div class="container">
            <div class="row">
                <div class="col-md-6 mx-auto">
                    <div class="section-title text-center mb-70">
                        <h2> قسمتی از کارخانه</h2>
                        <span><img src="assets/img/separ-logo.png" alt="separetor"></span>
                     
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <div class="single-blog">
                        <div class="img-date-wrape">
                            <img src="assets/img/blog/blog-1.jpg" alt="" class="img-fluid" />
                         
                        </div>
                        <div class="blog-content">
                            <h3><a href="#">  واحد ماشینکاری</a></h3>
                            <span></span>
                            
                        </div>

                    </div>
                </div>

                <div class="col-md-4">
                    <div class="single-blog">
                        <div class="img-date-wrape">
                            <img src="assets/img/blog/blog-2.jpg" alt="" class="img-fluid" />
                 
                        </div>
                        <div class="blog-content">
                            <h3><a href="#"> آزمایشگاه</a></h3>
                            <span></span>
                          
                        </div>

                    </div>
                </div>

                <div class="col-md-4">
                    <div class="single-blog">
                        <div class="img-date-wrape">
                            <img src="assets/img/blog/blog-3.jpg" alt="" class="img-fluid" />
                         
                        </div>
                        <div class="blog-content">
                            <h3><a href="#">  واحد تولید لنت</a></h3>
                            <span></span>
                          
                        </div>

                    </div>
                </div>
            </div>
            <div class="spacer-15"></div>
            <div class="row">
                <div class="col-md-4">
                    <div class="single-blog">
                        <div class="img-date-wrape">
                            <img src="assets/img/blog/blog-4.jpg" alt="" class="img-fluid" />
                     
                        </div>
                        <div class="blog-content">
                            <h3><a href="#">  واحد مونتاژ اکسل</a></h3>
                            <span></span>
                           
                        </div>

                    </div>
                </div>

                <div class="col-md-4">
                    <div class="single-blog">
                        <div class="img-date-wrape">
                            <img src="assets/img/blog/blog-5.jpg" alt="" class="img-fluid" />
                      
                        </div>
                        <div class="blog-content">
                            <h3><a href="#"> واحد رباتیک</a></h3>
                            <span></span>
                           
                        </div>

                    </div>
                </div>

                <div class="col-md-4">
                    <div class="single-blog">
                        <div class="img-date-wrape">
                            <img src="assets/img/blog/blog-6.jpg" alt="" class="img-fluid" />
                            
                        </div>
                        <div class="blog-content">
                            <h3><a href="#">    واحد پرس کاری</a></h3>
                            <span></span>
                         
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- blog area end -->


    <!-- client slider area end -->
   

<?php 
include_once("footer.php");

?>
