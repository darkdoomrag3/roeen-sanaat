 <!-- footer area start -->
 <div class="footer-area black-bg sec-p-100">
     <div class="container">
         <div class="row">
             <div class="col-md-3 col-sm-6">
                 <div class="footer-widget widget-1">
                     <div class="footer-logo">
                         <a href="#"><img src="assets/img/logo.png" alt="footer-logo" class="img-fluid" /></a>
                     </div>

                     <p> شرکت روئین صنعت نوین بالغ بر ۳۰ سال است که در صنعت خودرو کشور مشغول به فعالیت می باشد این شرکت
                         در شهرهای اصفهان و تهران در ۴ شعبه با تولیدات مختلف همیشه سعی داردتا با پیشرفتهای روز جهانی
                         همگام و پیشگام در بروز رسانی در این عرصه بوده .استفاده از تجهیزات روز دنیا در زمینه تولید و
                         اندازه گیری و کنترل از افتخارات این شرکت می باشد. </p>
                 </div>
             </div>




             <div class="col-md-3 col-sm-6">
                 <div class="footer-widget widget-3">
                     <h3>اطلاعات تماس</h3>
                     <div class="office-address border-bottom mb-20 pb-20">
                         <h4><a href="#"> آدرس ایمیل</a></h4>
                         <p>info@roeensanat.com </p>
                         <p>roeensanat@yahoo.com</p>
                         <p> تلفن و تلفکس </p>
                         <p> 021-46892647-50 </p>
                     </div>
                    
                 </div>
             </div>
         </div>
     </div>
 </div>
 <div class="footer-copyright">
     <div class="container">
         <div class="row">
             <div class="col-md-12">
                 <div class="copy-right text-center">
                     <a href="http://deymdevelop.com">طراحی سایت توسط Deymdevelop</a>


                     کلیه حقوق مادی و معنوی این وب سایت برای شرکت رویین صنعت نوین محفوظ است
                 </div>
             </div>
         </div>
     </div>
 </div>
 <!-- footer area end -->


 <!-- scrolltop button -->
 <div class="material-scrolltop"></div>

 <!-- JS here -->
 <script src="assets/js/vendor/modernizr-3.5.0.min.js"></script>
 <script src="assets/js/vendor/jquery-1.12.4.min.js"></script>
 <script src="assets/js/popper.min.js"></script>
 <script src="assets/js/bootstrap.min.js"></script>
 <script src="assets/js/meanmenu.min.js"></script>
 <script src="assets/js/owl.carousel.min.js"></script>
 <script src="assets/js/waypoints.min.js"></script>
 <script src="assets/js/counterup.min.js"></script>
 <script src="assets/js/jquery-ui.js"></script>
 <script src="assets/js/jquery.barfiller.js"></script>
 <script src="assets/js/isotope.pkgd.min.js"></script>
 <script src="assets/js/imagesloaded.min.js"></script>
 <script src="assets/js/magnific-popup.min.js"></script>
 <script src="assets/js/nice-select.min.js"></script>
 <script src="assets/js/scrolltop.js"></script>
 <script src="assets/js/wow.min.js"></script>
 <script src="assets/js/ajax-form.js"></script>
 <script src="assets/js/plugins.js"></script>
 <script src="assets/js/main.js"></script>
 </body>

 </html>