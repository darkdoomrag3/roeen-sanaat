<?php 
include_once("header.php");

?>





<!-- header area end -->
<!-- hero area start -->

<!-- main menu area end -->
<!-- breadcroumb area start -->
<div class="tractour-breadcroumb breadcroumb-bg text-center">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h2> قطعات سمند </h2>
                <h4><a href="index.php">صفحه اصلی </a>قطعات سمند</h4>
            </div>
        </div>
    </div>
</div>
<!-- breadcroumb area end -->
</div>
<!-- hero area end -->
<!-- shop area start -->
<div class="shop-area sec-p-100">
    <div class="container">
        <div class="row">


        </div>
        <div class="spacer-20"></div>
        <div class="row"><div class="col-md-3">
                <div class="single-product-wrap text-center">
                    <div class="">
                        <a href="#">
                            <img src="assets/img/shop/parts/قطعات سمند/اهرم ترمز دستی سمند EF7.jpg" alt="product" class="img-fluid" /></a>


                        <div class="sale-tag">

                        </div>
                    </div>
                    <div class="product-content">
                        <h4><a href="#" class="product-title">اهرم ترمز دستی سمند EF7</a></h4>
                        <div class="product-price">

                        </div>

                    </div>
                </div>
            </div>


<div class="col-md-3">
                <div class="single-product-wrap text-center">
                    <div class="">
                        <a href="#">
                            <img src="assets/img/shop/parts/قطعات سمند/لنت جلو سمند ملی.jpg" alt="product" class="img-fluid" /></a>


                        <div class="sale-tag">

                        </div>
                    </div>
                    <div class="product-content">
                        <h4><a href="#" class="product-title">لنت جلو سمند ملی</a></h4>
                        <div class="product-price">

                        </div>

                    </div>
                </div>
            </div>


<div class="col-md-3">
                <div class="single-product-wrap text-center">
                    <div class="">
                        <a href="#">
                            <img src="assets/img/shop/parts/قطعات سمند/لنت عقب سمند ملی.jpg" alt="product" class="img-fluid" /></a>


                        <div class="sale-tag">

                        </div>
                    </div>
                    <div class="product-content">
                        <h4><a href="#" class="product-title">لنت عقب سمند ملی</a></h4>
                        <div class="product-price">

                        </div>

                    </div>
                </div>
            </div>


<div class="col-md-3">
                <div class="single-product-wrap text-center">
                    <div class="">
                        <a href="#">
                            <img src="assets/img/shop/parts/قطعات سمند/لنت عقب سمند کار.jpg" alt="product" class="img-fluid" /></a>


                        <div class="sale-tag">

                        </div>
                    </div>
                    <div class="product-content">
                        <h4><a href="#" class="product-title">لنت عقب سمند کار</a></h4>
                        <div class="product-price">

                        </div>

                    </div>
                </div>
            </div>


<div class="col-md-3">
                <div class="single-product-wrap text-center">
                    <div class="">
                        <a href="#">
                            <img src="assets/img/shop/parts/قطعات سمند/کفشک جلو سمند ملی.jpg" alt="product" class="img-fluid" /></a>


                        <div class="sale-tag">

                        </div>
                    </div>
                    <div class="product-content">
                        <h4><a href="#" class="product-title">کفشک جلو سمند ملی</a></h4>
                        <div class="product-price">

                        </div>

                    </div>
                </div>
            </div>


<div class="col-md-3">
                <div class="single-product-wrap text-center">
                    <div class="">
                        <a href="#">
                            <img src="assets/img/shop/parts/قطعات سمند/کفشک عقب سمند ملی.jpg" alt="product" class="img-fluid" /></a>


                        <div class="sale-tag">

                        </div>
                    </div>
                    <div class="product-content">
                        <h4><a href="#" class="product-title">کفشک عقب سمند ملی</a></h4>
                        <div class="product-price">

                        </div>

                    </div>
                </div>
            </div>


                </div>
            </div>


        </div>
    </div>
</div>
    <!-- quote sologan area end -->
    <!-- footer area start -->


    <?php 
    include_once("footer.php");


    ?> 