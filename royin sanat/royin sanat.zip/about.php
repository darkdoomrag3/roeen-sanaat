<?php
include_once("header.php");

?>


        <!-- main menu area end -->
        <!-- breadcroumb area start -->
        <div class="tractour-breadcroumb breadcroumb-bg text-center">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <h2>درباره</h2>
                        <h4><a href="index-2.html">صفحه اصلی </a>/ افتخارات</h4>
                    </div>
                </div>
            </div>
        </div>
        <!-- breadcroumb area end -->
    </div>
    <!-- hero area end -->
    <!-- about us area start -->
    <div class="about-area sec-p-100 text-center">
        <div class="container">
            <div class="row">

                <div class="col-md-8 mx-auto">
                    <div class="about-slider-wraper owl-carousel owl-theme mb-20">
                        <div class="about-single-item">
                            <img src="assets/img/about/about-1.jpg" alt="about-img" class="img-fluid" />
                            <h4>فن آوری های تجربی صنعتی</h4>
                        </div>
                        <div class="about-single-item">
                            <img src="assets/img/about/about-2.jpg" alt="about-img" class="img-fluid" />
                            <h4>فن آوری های تجربی صنعتی</h4>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <h2>در مورد تاریخ ما</h2>
                    <p>اما من باید به شما توضیح دهم که چگونه تمام این ایده اشتباه محکومیت درد و شکیبایی لذت بخش متولد شد و من به شما یک حساب کامل از این سیستم ارائه می دهم، تعالیم واقعی حقیقت بزرگ، حقیقت سازنده شادی انسان را شرح می دهم. هیچکس خود را رد نمیکند، دوست ندارد یا از لذت خود اجتناب میکند، زیرا لذت بردن است، اما به این دلیل که کسانی که نمیدانند چگونه عواقب روحی روانی را دنبال میکنند بسیار دردناک است. نه دوباره کسی وجود دارد که دوست دارد یا پیروی یا تمایل خودش را داشته باشد ولی من باید به شما توضیح دهم که چگونه تمام این ایده اشتباه محکومیت من و لذت و قدردانی از درد متولد شد و من به شما یک حساب کامل از سیستم داده و توضیح خواهم داد آموزه های واقعی </p>
                </div>
            </div>
        </div>
    </div>
    <!-- about us area end -->
    <!-- quote sologan area start -->
  
    <!-- quote sologan area end -->
    <!-- footer area start -->
   <?php

include_once("footer.php");

   ?>