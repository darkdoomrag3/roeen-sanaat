 <!-- footer area start -->
 <div class="footer-area black-bg sec-p-100">
     <div class="container">
         <div class="row">
             <div class="col-md-3 col-sm-6">
                 <div class="footer-widget widget-1">
                     <div class="footer-logo">
                         <a href="#"><img src="assets/img/logo.png" alt="footer-logo" class="img-fluid" /></a>
                     </div>

                     <p> Roeen new industrial Co. has been participating in automobile
                      parts manufacturing for the past thirty years. 
                        The company headquarter is located in Tehran 
                        along with four parts manufacturing plants in Tehran and Isfahan.</p>
                 </div>
             </div>




             <div class="col-md-3 col-sm-6">
                 <div class="footer-widget widget-3">
                     <h3>Contact Info</h3>
                     <div class="office-address border-bottom mb-20 pb-20">
                         <h4><a href="#">Email Addresses</a></h4>
                         <p>info@roeensanat.com </p>
                         <p>roeensanat@yahoo.com</p>
                         <p> Telephone & Fax </p>
                         <p> 021-46892647-50 </p>
                     </div>
                    
                 </div>
             </div>
         </div>
     </div>
 </div>
 <div class="footer-copyright">
     <div class="container">
         <div class="row">
             <div class="col-md-12">
                 <div class="copy-right text-center">
                     <a href="http://deymdevelop.com">Web Design by Deymdevelop</a>


                     Roeen Sanaat Novin Co (c) All Rights Reserved.
                 </div>
             </div>
         </div>
     </div>
 </div>
 <!-- footer area end -->


 <!-- scrolltop button -->
 <div class="material-scrolltop"></div>

 <!-- JS here -->
 <script src="assets/js/vendor/modernizr-3.5.0.min.js"></script>
 <script src="assets/js/vendor/jquery-1.12.4.min.js"></script>
 <script src="assets/js/popper.min.js"></script>
 <script src="assets/js/bootstrap.min.js"></script>
 <script src="assets/js/meanmenu.min.js"></script>
 <script src="assets/js/owl.carousel.min.js"></script>
 <script src="assets/js/waypoints.min.js"></script>
 <script src="assets/js/counterup.min.js"></script>
 <script src="assets/js/jquery-ui.js"></script>
 <script src="assets/js/jquery.barfiller.js"></script>
 <script src="assets/js/isotope.pkgd.min.js"></script>
 <script src="assets/js/imagesloaded.min.js"></script>
 <script src="assets/js/magnific-popup.min.js"></script>
 <script src="assets/js/nice-select.min.js"></script>
 <script src="assets/js/scrolltop.js"></script>
 <script src="assets/js/wow.min.js"></script>
 <script src="assets/js/ajax-form.js"></script>
 <script src="assets/js/plugins.js"></script>
 <script src="assets/js/main.js"></script>
 </body>

 </html>