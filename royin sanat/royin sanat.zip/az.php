<?php
include_once("header.php");

?>



    <!-- hero area end -->
    <!-- blog area start -->
    <div class="blog-area sec-p-100">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <div class="single-blog">
                        <div class="img-date-wrape">
                            <img src="assets/img/blog/blog-2.jpg" alt="" class="img-fluid" />
                           
                        </div>
                        <div class="blog-content">
                           
                        </div>

                    </div>
                </div>

                <div class="col-md-4">
                    <div class="single-blog">
                        <div class="img-date-wrape">
                            <img src="assets/img/blog/2.jpg" alt="" class="img-fluid" />
                       
                        </div>
                        <div class="blog-content">
                        
                        </div>

                    </div>
                </div>

                <div class="col-md-4">
                    <div class="single-blog">
                        <div class="img-date-wrape">
                            <img src="assets/img/blog/3.jpg" alt="" class="img-fluid" />
                            
                        </div>
                        <div class="blog-content">
                         
                   
                        </div>

                    </div>
                </div>
            </div>
            <div class="spacer-15"></div>
            <div class="row">
                <div class="col-md-4">
                    <div class="single-blog">
                        <div class="img-date-wrape">
                            <img src="assets/img/blog/4.jpg" alt="" class="img-fluid" />
                          
                        </div>
                        <div class="blog-content">
                    
                        </div>

                    </div>
                </div>

                <div class="col-md-4">
                    <div class="single-blog">
                        <div class="img-date-wrape">
                            <img src="assets/img/blog/5.jpg" alt="" class="img-fluid" />
                           
                        </div>
                        <div class="blog-content">
                          
                  
                        </div>

                    </div>
                </div>

                <div class="col-md-4">
                    <div class="single-blog">
                        <div class="img-date-wrape">
                            <img src="assets/img/blog/6.jpg" alt="" class="img-fluid" />
                           
                        </div>
                        <div class="blog-content">
            
                        </div>

                    </div>
                </div>
            </div>

            <div class="spacer-15"></div>
            <div class="row">
                <div class="col-md-4">
                    <div class="single-blog">
                        <div class="img-date-wrape">
                            <img src="assets/img/blog/7.jpg" alt="" class="img-fluid" />
                          
                        </div>
                        <div class="blog-content">
                        
                        </div>

                    </div>
                </div>

                <div class="col-md-4">
                    <div class="single-blog">
                        <div class="img-date-wrape">
                            <img src="assets/img/blog/8.jpg" alt="" class="img-fluid" />
                         
                        </div>
                        <div class="blog-content">
                      
                        </div>

                    </div>
                </div>

                <div class="col-md-4">
                    <div class="single-blog">
                        <div class="img-date-wrape">
                            <img src="assets/img/blog/9.jpg" alt="" class="img-fluid" />
                           
                        </div>
                        <div class="blog-content">
                         
                         
                        </div>

                    </div>
                </div>
            </div>
         
        </div>
    </div>
    <!-- blog area end -->
   
    <!-- quote sologan area end -->
    

<?php
include_once("footer.php");

?>

