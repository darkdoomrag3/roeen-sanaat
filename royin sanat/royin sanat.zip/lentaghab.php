<?php 
include_once("header.php");

?>





<!-- header area end -->
<!-- hero area start -->

<!-- main menu area end -->
<!-- breadcroumb area start -->
<div class="tractour-breadcroumb breadcroumb-bg text-center">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h2> انواع لنت عقب </h2>
                <h4><a href="index.php">صفحه اصلی </a>انواع لنت عقب</h4>
            </div>
        </div>
    </div>
</div>
<!-- breadcroumb area end -->
</div>
<!-- hero area end -->
<!-- shop area start -->
<div class="shop-area sec-p-100">
    <div class="container">
        <div class="row">


        </div>
        <div class="spacer-20"></div>
        <div class="row"><div class="col-md-3">
                <div class="single-product-wrap text-center">
                    <div class="">
                        <a href="#">
                            <img src="assets/img/shop/parts/انواع لنت عقب/لنت عقب L90 فول.jpg" alt="product" class="img-fluid" /></a>


                        <div class="sale-tag">

                        </div>
                    </div>
                    <div class="product-content">
                        <h4><a href="#" class="product-title">لنت عقب L90 فول</a></h4>
                        <div class="product-price">

                        </div>

                    </div>
                </div>
            </div>


<div class="col-md-3">
                <div class="single-product-wrap text-center">
                    <div class="">
                        <a href="#">
                            <img src="assets/img/shop/parts/انواع لنت عقب/لنت عقب تیبا ریویی.jpg" alt="product" class="img-fluid" /></a>


                        <div class="sale-tag">

                        </div>
                    </div>
                    <div class="product-content">
                        <h4><a href="#" class="product-title">لنت عقب تیبا ریویی</a></h4>
                        <div class="product-price">

                        </div>

                    </div>
                </div>
            </div>


<div class="col-md-3">
                <div class="single-product-wrap text-center">
                    <div class="">
                        <a href="#">
                            <img src="assets/img/shop/parts/انواع لنت عقب/لنت عقب تیبا طرح بوش.jpg" alt="product" class="img-fluid" /></a>


                        <div class="sale-tag">

                        </div>
                    </div>
                    <div class="product-content">
                        <h4><a href="#" class="product-title">لنت عقب تیبا طرح بوش</a></h4>
                        <div class="product-price">

                        </div>

                    </div>
                </div>
            </div>


<div class="col-md-3">
                <div class="single-product-wrap text-center">
                    <div class="">
                        <a href="#">
                            <img src="assets/img/shop/parts/انواع لنت عقب/لنت عقب سمند ملی.jpg" alt="product" class="img-fluid" /></a>


                        <div class="sale-tag">

                        </div>
                    </div>
                    <div class="product-content">
                        <h4><a href="#" class="product-title">لنت عقب سمند ملی</a></h4>
                        <div class="product-price">

                        </div>

                    </div>
                </div>
            </div>


<div class="col-md-3">
                <div class="single-product-wrap text-center">
                    <div class="">
                        <a href="#">
                            <img src="assets/img/shop/parts/انواع لنت عقب/لنت عقب سمند کار.jpg" alt="product" class="img-fluid" /></a>


                        <div class="sale-tag">

                        </div>
                    </div>
                    <div class="product-content">
                        <h4><a href="#" class="product-title">لنت عقب سمند کار</a></h4>
                        <div class="product-price">

                        </div>

                    </div>
                </div>
            </div>


<div class="col-md-3">
                <div class="single-product-wrap text-center">
                    <div class="">
                        <a href="#">
                            <img src="assets/img/shop/parts/انواع لنت عقب/لنت عقب پراید.jpg" alt="product" class="img-fluid" /></a>


                        <div class="sale-tag">

                        </div>
                    </div>
                    <div class="product-content">
                        <h4><a href="#" class="product-title">لنت عقب پراید</a></h4>
                        <div class="product-price">

                        </div>

                    </div>
                </div>
            </div>


<div class="col-md-3">
                <div class="single-product-wrap text-center">
                    <div class="">
                        <a href="#">
                            <img src="assets/img/shop/parts/انواع لنت عقب/لنت عقب پژو 206 تیپ 2.jpg" alt="product" class="img-fluid" /></a>


                        <div class="sale-tag">

                        </div>
                    </div>
                    <div class="product-content">
                        <h4><a href="#" class="product-title">لنت عقب پژو 206 تیپ 2</a></h4>
                        <div class="product-price">

                        </div>

                    </div>
                </div>
            </div>


<div class="col-md-3">
                <div class="single-product-wrap text-center">
                    <div class="">
                        <a href="#">
                            <img src="assets/img/shop/parts/انواع لنت عقب/لنت عقب پژو 405.jpg" alt="product" class="img-fluid" /></a>


                        <div class="sale-tag">

                        </div>
                    </div>
                    <div class="product-content">
                        <h4><a href="#" class="product-title">لنت عقب پژو 405</a></h4>
                        <div class="product-price">

                        </div>

                    </div>
                </div>
            </div>


<div class="col-md-3">
                <div class="single-product-wrap text-center">
                    <div class="">
                        <a href="#">
                            <img src="assets/img/shop/parts/انواع لنت عقب/لنت عقب پیکان.jpg" alt="product" class="img-fluid" /></a>


                        <div class="sale-tag">

                        </div>
                    </div>
                    <div class="product-content">
                        <h4><a href="#" class="product-title">لنت عقب پیکان</a></h4>
                        <div class="product-price">

                        </div>

                    </div>
                </div>
            </div>


                </div>
            </div>


        </div>
    </div>
</div>
    <!-- quote sologan area end -->
    <!-- footer area start -->


    <?php 
    include_once("footer.php");


    ?> 