<?php 
include_once("header.php");

?>





<!-- header area end -->
<!-- hero area start -->

<!-- main menu area end -->
<!-- breadcroumb area start -->
<div class="tractour-breadcroumb breadcroumb-bg text-center">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h2> قطعات دیگر </h2>
                <h4><a href="index.php">صفحه اصلی </a>قطعات دیگر</h4>
            </div>
        </div>
    </div>
</div>
<!-- breadcroumb area end -->
</div>
<!-- hero area end -->
<!-- shop area start -->
<div class="shop-area sec-p-100">
    <div class="container">
        <div class="row">


        </div>
        <div class="spacer-20"></div>
        <div class="row"><div class="col-md-3">
                <div class="single-product-wrap text-center">
                    <div class="">
                        <a href="#">
                            <img src="assets/img/shop/parts/قطعات دیگر/براکت  شیلنگ.jpg" alt="product" class="img-fluid" /></a>


                        <div class="sale-tag">

                        </div>
                    </div>
                    <div class="product-content">
                        <h4><a href="#" class="product-title">براکت  شیلنگ</a></h4>
                        <div class="product-price">

                        </div>

                    </div>
                </div>
            </div>


<div class="col-md-3">
                <div class="single-product-wrap text-center">
                    <div class="">
                        <a href="#">
                            <img src="assets/img/shop/parts/قطعات دیگر/براکت اکسل تیبا.jpg" alt="product" class="img-fluid" /></a>


                        <div class="sale-tag">

                        </div>
                    </div>
                    <div class="product-content">
                        <h4><a href="#" class="product-title">براکت اکسل تیبا</a></h4>
                        <div class="product-price">

                        </div>

                    </div>
                </div>
            </div>


<div class="col-md-3">
                <div class="single-product-wrap text-center">
                    <div class="">
                        <a href="#">
                            <img src="assets/img/shop/parts/قطعات دیگر/توپی تیبا و 151.jpg" alt="product" class="img-fluid" /></a>


                        <div class="sale-tag">

                        </div>
                    </div>
                    <div class="product-content">
                        <h4><a href="#" class="product-title">توپی تیبا و 151</a></h4>
                        <div class="product-price">

                        </div>

                    </div>
                </div>
            </div>


<div class="col-md-3">
                <div class="single-product-wrap text-center">
                    <div class="">
                        <a href="#">
                            <img src="assets/img/shop/parts/قطعات دیگر/توپی پراید.jpg" alt="product" class="img-fluid" /></a>


                        <div class="sale-tag">

                        </div>
                    </div>
                    <div class="product-content">
                        <h4><a href="#" class="product-title">توپی پراید</a></h4>
                        <div class="product-price">

                        </div>

                    </div>
                </div>
            </div>


<div class="col-md-3">
                <div class="single-product-wrap text-center">
                    <div class="">
                        <a href="#">
                            <img src="assets/img/shop/parts/قطعات دیگر/دیسک جلو پراید-2.jpg" alt="product" class="img-fluid" /></a>


                        <div class="sale-tag">

                        </div>
                    </div>
                    <div class="product-content">
                        <h4><a href="#" class="product-title">دیسک جلو پراید-2</a></h4>
                        <div class="product-price">

                        </div>

                    </div>
                </div>
            </div>


<div class="col-md-3">
                <div class="single-product-wrap text-center">
                    <div class="">
                        <a href="#">
                            <img src="assets/img/shop/parts/قطعات دیگر/دیسک جلو پراید.jpg" alt="product" class="img-fluid" /></a>


                        <div class="sale-tag">

                        </div>
                    </div>
                    <div class="product-content">
                        <h4><a href="#" class="product-title">دیسک جلو پراید</a></h4>
                        <div class="product-price">

                        </div>

                    </div>
                </div>
            </div>


<div class="col-md-3">
                <div class="single-product-wrap text-center">
                    <div class="">
                        <a href="#">
                            <img src="assets/img/shop/parts/قطعات دیگر/رام L90.jpg" alt="product" class="img-fluid" /></a>


                        <div class="sale-tag">

                        </div>
                    </div>
                    <div class="product-content">
                        <h4><a href="#" class="product-title">رام L90</a></h4>
                        <div class="product-price">

                        </div>

                    </div>
                </div>
            </div>


<div class="col-md-3">
                <div class="single-product-wrap text-center">
                    <div class="">
                        <a href="#">
                            <img src="assets/img/shop/parts/قطعات دیگر/سیلندر ترمز تیبا.jpg" alt="product" class="img-fluid" /></a>


                        <div class="sale-tag">

                        </div>
                    </div>
                    <div class="product-content">
                        <h4><a href="#" class="product-title">سیلندر ترمز تیبا</a></h4>
                        <div class="product-price">

                        </div>

                    </div>
                </div>
            </div>


<div class="col-md-3">
                <div class="single-product-wrap text-center">
                    <div class="">
                        <a href="#">
                            <img src="assets/img/shop/parts/قطعات دیگر/سیلندر ترمز پراید.jpg" alt="product" class="img-fluid" /></a>


                        <div class="sale-tag">

                        </div>
                    </div>
                    <div class="product-content">
                        <h4><a href="#" class="product-title">سیلندر ترمز پراید</a></h4>
                        <div class="product-price">

                        </div>

                    </div>
                </div>
            </div>


<div class="col-md-3">
                <div class="single-product-wrap text-center">
                    <div class="">
                        <a href="#">
                            <img src="assets/img/shop/parts/قطعات دیگر/صفحه سیستم تیبا.jpg" alt="product" class="img-fluid" /></a>


                        <div class="sale-tag">

                        </div>
                    </div>
                    <div class="product-content">
                        <h4><a href="#" class="product-title">صفحه سیستم تیبا</a></h4>
                        <div class="product-price">

                        </div>

                    </div>
                </div>
            </div>


<div class="col-md-3">
                <div class="single-product-wrap text-center">
                    <div class="">
                        <a href="#">
                            <img src="assets/img/shop/parts/قطعات دیگر/صفحه سیستم پراید.jpg" alt="product" class="img-fluid" /></a>


                        <div class="sale-tag">

                        </div>
                    </div>
                    <div class="product-content">
                        <h4><a href="#" class="product-title">صفحه سیستم پراید</a></h4>
                        <div class="product-price">

                        </div>

                    </div>
                </div>
            </div>


<div class="col-md-3">
                <div class="single-product-wrap text-center">
                    <div class="">
                        <a href="#">
                            <img src="assets/img/shop/parts/قطعات دیگر/مجموعه ترمز عقب تیبا.jpg" alt="product" class="img-fluid" /></a>


                        <div class="sale-tag">

                        </div>
                    </div>
                    <div class="product-content">
                        <h4><a href="#" class="product-title">مجموعه ترمز عقب تیبا</a></h4>
                        <div class="product-price">

                        </div>

                    </div>
                </div>
            </div>


<div class="col-md-3">
                <div class="single-product-wrap text-center">
                    <div class="">
                        <a href="#">
                            <img src="assets/img/shop/parts/قطعات دیگر/مجموعه ترمز عقب وانت پراید 151.jpg" alt="product" class="img-fluid" /></a>


                        <div class="sale-tag">

                        </div>
                    </div>
                    <div class="product-content">
                        <h4><a href="#" class="product-title">مجموعه ترمز عقب وانت پراید 151</a></h4>
                        <div class="product-price">

                        </div>

                    </div>
                </div>
            </div>


<div class="col-md-3">
                <div class="single-product-wrap text-center">
                    <div class="">
                        <a href="#">
                            <img src="assets/img/shop/parts/قطعات دیگر/مجموعه ترمز عقب پراید.jpg" alt="product" class="img-fluid" /></a>


                        <div class="sale-tag">

                        </div>
                    </div>
                    <div class="product-content">
                        <h4><a href="#" class="product-title">مجموعه ترمز عقب پراید</a></h4>
                        <div class="product-price">

                        </div>

                    </div>
                </div>
            </div>


<div class="col-md-3">
                <div class="single-product-wrap text-center">
                    <div class="">
                        <a href="#">
                            <img src="assets/img/shop/parts/قطعات دیگر/مجموعه کالیپر تیبا.jpg" alt="product" class="img-fluid" /></a>


                        <div class="sale-tag">

                        </div>
                    </div>
                    <div class="product-content">
                        <h4><a href="#" class="product-title">مجموعه کالیپر تیبا</a></h4>
                        <div class="product-price">

                        </div>

                    </div>
                </div>
            </div>


<div class="col-md-3">
                <div class="single-product-wrap text-center">
                    <div class="">
                        <a href="#">
                            <img src="assets/img/shop/parts/قطعات دیگر/کلیپر تیبا.jpg" alt="product" class="img-fluid" /></a>


                        <div class="sale-tag">

                        </div>
                    </div>
                    <div class="product-content">
                        <h4><a href="#" class="product-title">کلیپر تیبا</a></h4>
                        <div class="product-price">

                        </div>

                    </div>
                </div>
            </div>


                </div>
            </div>


        </div>
    </div>
</div>
    <!-- quote sologan area end -->
    <!-- footer area start -->


    <?php 
    include_once("footer.php");


    ?> 