<?php 
include_once("header-eng.php");

?>





<!-- header area end -->
<!-- hero area start -->

<!-- main menu area end -->
<!-- breadcroumb area start -->
<div class="tractour-breadcroumb breadcroumb-bg text-center">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h2> Tiba </h2>
                <h4><a href="index.php">Homepage </a>Tiba</h4>
            </div>
        </div>
    </div>
</div>
<!-- breadcroumb area end -->
</div>
<!-- hero area end -->
<!-- shop area start -->
<div class="shop-area sec-p-100">
    <div class="container">
        <div class="row">


        </div>
        <div class="spacer-20"></div>
        <div class="row"><div class="col-md-3">
                <div class="single-product-wrap text-center">
                    <div class="">
                        <a href="#">
                            <img src="assets/img/shop/parts/Tiba/ABS Tiba Plate Assy.R.Back.jpg" alt="product" class="img-fluid" /></a>


                        <div class="sale-tag">

                        </div>
                    </div>
                    <div class="product-content">
                        <h4><a href="#" class="product-title">ABS Tiba Plate Assy</a></h4>
                        <div class="product-price">

                        </div>

                    </div>
                </div>
            </div>


<div class="col-md-3">
                <div class="single-product-wrap text-center">
                    <div class="">
                        <a href="#">
                            <img src="assets/img/shop/parts/Tiba/Tiba & 151 Rear Hub Spindle.jpg" alt="product" class="img-fluid" /></a>


                        <div class="sale-tag">

                        </div>
                    </div>
                    <div class="product-content">
                        <h4><a href="#" class="product-title">Tiba & 151 Rear Hub Spindle</a></h4>
                        <div class="product-price">

                        </div>

                    </div>
                </div>
            </div>


<div class="col-md-3">
                <div class="single-product-wrap text-center">
                    <div class="">
                        <a href="#">
                            <img src="assets/img/shop/parts/Tiba/Tiba 2 Rear Axle.jpg" alt="product" class="img-fluid" /></a>


                        <div class="sale-tag">

                        </div>
                    </div>
                    <div class="product-content">
                        <h4><a href="#" class="product-title">Tiba 2 Rear Axle</a></h4>
                        <div class="product-price">

                        </div>

                    </div>
                </div>
            </div>


<div class="col-md-3">
                <div class="single-product-wrap text-center">
                    <div class="">
                        <a href="#">
                            <img src="assets/img/shop/parts/Tiba/Tiba Brake Assy Front Disk.jpg" alt="product" class="img-fluid" /></a>


                        <div class="sale-tag">

                        </div>
                    </div>
                    <div class="product-content">
                        <h4><a href="#" class="product-title">Tiba Brake Assy Front Disk</a></h4>
                        <div class="product-price">

                        </div>

                    </div>
                </div>
            </div>


<div class="col-md-3">
                <div class="single-product-wrap text-center">
                    <div class="">
                        <a href="#">
                            <img src="assets/img/shop/parts/Tiba/Tiba Brake Assy.jpg" alt="product" class="img-fluid" /></a>


                        <div class="sale-tag">

                        </div>
                    </div>
                    <div class="product-content">
                        <h4><a href="#" class="product-title">Tiba Brake Assy</a></h4>
                        <div class="product-price">

                        </div>

                    </div>
                </div>
            </div>


<div class="col-md-3">
                <div class="single-product-wrap text-center">
                    <div class="">
                        <a href="#">
                            <img src="assets/img/shop/parts/Tiba/Tiba Brake Front Disk.jpg" alt="product" class="img-fluid" /></a>


                        <div class="sale-tag">

                        </div>
                    </div>
                    <div class="product-content">
                        <h4><a href="#" class="product-title">Tiba Brake Front Disk</a></h4>
                        <div class="product-price">

                        </div>

                    </div>
                </div>
            </div>


<div class="col-md-3">
                <div class="single-product-wrap text-center">
                    <div class="">
                        <a href="#">
                            <img src="assets/img/shop/parts/Tiba/Tiba Excel Braket.jpg" alt="product" class="img-fluid" /></a>


                        <div class="sale-tag">

                        </div>
                    </div>
                    <div class="product-content">
                        <h4><a href="#" class="product-title">Tiba Excel Braket</a></h4>
                        <div class="product-price">

                        </div>

                    </div>
                </div>
            </div>


<div class="col-md-3">
                <div class="single-product-wrap text-center">
                    <div class="">
                        <a href="#">
                            <img src="assets/img/shop/parts/Tiba/Tiba Junior Shoes (Bosh).jpg" alt="product" class="img-fluid" /></a>


                        <div class="sale-tag">

                        </div>
                    </div>
                    <div class="product-content">
                        <h4><a href="#" class="product-title">Tiba Junior Shoes (Bosh)</a></h4>
                        <div class="product-price">

                        </div>

                    </div>
                </div>
            </div>


<div class="col-md-3">
                <div class="single-product-wrap text-center">
                    <div class="">
                        <a href="#">
                            <img src="assets/img/shop/parts/Tiba/Tiba Junior Shoes (Rio).jpg" alt="product" class="img-fluid" /></a>


                        <div class="sale-tag">

                        </div>
                    </div>
                    <div class="product-content">
                        <h4><a href="#" class="product-title">Tiba Junior Shoes (Rio)</a></h4>
                        <div class="product-price">

                        </div>

                    </div>
                </div>
            </div>


<div class="col-md-3">
                <div class="single-product-wrap text-center">
                    <div class="">
                        <a href="#">
                            <img src="assets/img/shop/parts/Tiba/Tiba Operating Lever (Bosh).jpg" alt="product" class="img-fluid" /></a>


                        <div class="sale-tag">

                        </div>
                    </div>
                    <div class="product-content">
                        <h4><a href="#" class="product-title">Tiba Operating Lever (Bosh)</a></h4>
                        <div class="product-price">

                        </div>

                    </div>
                </div>
            </div>


<div class="col-md-3">
                <div class="single-product-wrap text-center">
                    <div class="">
                        <a href="#">
                            <img src="assets/img/shop/parts/Tiba/Tiba Operating Lever (Rio).jpg" alt="product" class="img-fluid" /></a>


                        <div class="sale-tag">

                        </div>
                    </div>
                    <div class="product-content">
                        <h4><a href="#" class="product-title">Tiba Operating Lever (Rio)</a></h4>
                        <div class="product-price">

                        </div>

                    </div>
                </div>
            </div>


<div class="col-md-3">
                <div class="single-product-wrap text-center">
                    <div class="">
                        <a href="#">
                            <img src="assets/img/shop/parts/Tiba/Tiba Pickup Brakes.jpg" alt="product" class="img-fluid" /></a>


                        <div class="sale-tag">

                        </div>
                    </div>
                    <div class="product-content">
                        <h4><a href="#" class="product-title">Tiba Pickup Brakes</a></h4>
                        <div class="product-price">

                        </div>

                    </div>
                </div>
            </div>


<div class="col-md-3">
                <div class="single-product-wrap text-center">
                    <div class="">
                        <a href="#">
                            <img src="assets/img/shop/parts/Tiba/Tiba Rear Axle.jpg" alt="product" class="img-fluid" /></a>


                        <div class="sale-tag">

                        </div>
                    </div>
                    <div class="product-content">
                        <h4><a href="#" class="product-title">Tiba Rear Axle</a></h4>
                        <div class="product-price">

                        </div>

                    </div>
                </div>
            </div>


<div class="col-md-3">
                <div class="single-product-wrap text-center">
                    <div class="">
                        <a href="#">
                            <img src="assets/img/shop/parts/Tiba/Tiba Rear Brake pads (Bosh).jpg" alt="product" class="img-fluid" /></a>


                        <div class="sale-tag">

                        </div>
                    </div>
                    <div class="product-content">
                        <h4><a href="#" class="product-title">Tiba Rear Brake pads (Bosh)</a></h4>
                        <div class="product-price">

                        </div>

                    </div>
                </div>
            </div>


<div class="col-md-3">
                <div class="single-product-wrap text-center">
                    <div class="">
                        <a href="#">
                            <img src="assets/img/shop/parts/Tiba/Tiba Rear Brake pads (Rio).jpg" alt="product" class="img-fluid" /></a>


                        <div class="sale-tag">

                        </div>
                    </div>
                    <div class="product-content">
                        <h4><a href="#" class="product-title">Tiba Rear Brake pads (Rio)</a></h4>
                        <div class="product-price">

                        </div>

                    </div>
                </div>
            </div>


<div class="col-md-3">
                <div class="single-product-wrap text-center">
                    <div class="">
                        <a href="#">
                            <img src="assets/img/shop/parts/Tiba/Tiba Rear Cylinder.jpg" alt="product" class="img-fluid" /></a>


                        <div class="sale-tag">

                        </div>
                    </div>
                    <div class="product-content">
                        <h4><a href="#" class="product-title">Tiba Rear Cylinder</a></h4>
                        <div class="product-price">

                        </div>

                    </div>
                </div>
            </div>


                </div>
            </div>


        </div>
    </div>
</div>
    <!-- quote sologan area end -->
    <!-- footer area start -->


    <?php 
    include_once("footer-eng.php");


    ?> 